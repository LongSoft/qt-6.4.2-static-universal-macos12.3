#define QT_FEATURE_clock_gettime 1

#define QT_FEATURE_doubleconversion 1

#define QT_FEATURE_system_doubleconversion -1

#define QT_FEATURE_dladdr 1

#define QT_FEATURE_futimens 1

#define QT_FEATURE_futimes -1

#define QT_FEATURE_getauxval -1

#define QT_FEATURE_getentropy 1

#define QT_FEATURE_glib -1

#define QT_FEATURE_glibc -1

#define QT_FEATURE_icu -1

#define QT_FEATURE_inotify -1

#define QT_FEATURE_journald -1

#define QT_FEATURE_system_libb2 -1

#define QT_FEATURE_linkat -1

#define QT_FEATURE_mimetype_database 1

#define QT_FEATURE_system_pcre2 -1

#define QT_FEATURE_poll_ppoll -1

#define QT_FEATURE_poll_pollts -1

#define QT_FEATURE_poll_poll 1

#define QT_FEATURE_poll_select -1

#define QT_FEATURE_qqnx_pps -1

#define QT_FEATURE_renameat2 -1

#define QT_FEATURE_slog2 -1

#define QT_FEATURE_statx -1

#define QT_FEATURE_syslog -1

#define QT_FEATURE_backtrace 1

#define QT_FEATURE_cpp_winrt -1

#define QT_FEATURE_sha3_fast 1

#define QT_FEATURE_hijricalendar 1

#define QT_FEATURE_datetimeparser 1

#define QT_FEATURE_lttng -1

#define QT_FEATURE_etw -1

#define QT_FEATURE_forkfd_pidfd -1

