#define QT_FEATURE_use_bfd_linker -1

#define QT_FEATURE_use_gold_linker -1

#define QT_FEATURE_use_lld_linker -1

#define QT_FEATURE_use_mold_linker -1

#define QT_FEATURE_android_style_assets -1

#define QT_FEATURE_gc_binaries 1

#define QT_FEATURE_developer_build -1

#define QT_FEATURE_no_prefix -1

#define QT_FEATURE_private_tests -1

#define QT_FEATURE_debug -1

#define QT_FEATURE_reduce_exports 1

#define QT_FEATURE_no_direct_extern_access -1

#define QT_FEATURE_sse2 -1

#define QT_FEATURE_sse3 -1

#define QT_FEATURE_ssse3 -1

#define QT_FEATURE_sse4_1 -1

#define QT_FEATURE_sse4_2 -1

#define QT_FEATURE_avx -1

#define QT_FEATURE_f16c -1

#define QT_FEATURE_avx2 -1

#define QT_FEATURE_avx512f -1

#define QT_FEATURE_avx512er -1

#define QT_FEATURE_avx512cd -1

#define QT_FEATURE_avx512pf -1

#define QT_FEATURE_avx512dq -1

#define QT_FEATURE_avx512bw -1

#define QT_FEATURE_avx512vl -1

#define QT_FEATURE_avx512ifma -1

#define QT_FEATURE_avx512vbmi -1

#define QT_FEATURE_avx512vbmi2 -1

#define QT_FEATURE_aesni -1

#define QT_FEATURE_vaes -1

#define QT_FEATURE_rdrnd -1

#define QT_FEATURE_rdseed -1

#define QT_FEATURE_shani -1

#define QT_FEATURE_mips_dsp -1

#define QT_FEATURE_mips_dspr2 -1

#define QT_FEATURE_neon 1

#define QT_FEATURE_arm_crc32 -1

#define QT_FEATURE_arm_crypto -1

#define QT_FEATURE_posix_fallocate -1

#define QT_FEATURE_alloca_h 1

#define QT_FEATURE_alloca_malloc_h -1

#define QT_FEATURE_alloca 1

#define QT_FEATURE_stack_protector_strong -1

#define QT_FEATURE_system_zlib -1

#define QT_FEATURE_stdlib_libcpp -1

#define QT_FEATURE_dbus -1

#define QT_FEATURE_dbus_linked -1

#define QT_FEATURE_gui 1

#define QT_FEATURE_network 1

#define QT_FEATURE_printsupport 1

#define QT_FEATURE_sql 1

#define QT_FEATURE_testlib 1

#define QT_FEATURE_widgets 1

#define QT_FEATURE_xml 1

#define QT_FEATURE_libudev -1

#define QT_FEATURE_dlopen 1

#define QT_FEATURE_relocatable -1

#define QT_FEATURE_intelcet -1

